
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tempor',
  applicationName: 'tester',
  appUid: '9yCdZvP88hky4ClXg1',
  orgUid: '7acc9cab-a5d7-4586-9f43-219bd33bc886',
  deploymentUid: '63f51e16-2f78-4c81-9e19-7154399f963b',
  serviceName: 'certbackend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'certbackend-dev-listItems', timeout: 6 };

try {
  const userHandler = require('./listItems.js');
  module.exports.handler = serverlessSDK.handler(userHandler.listItems, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}