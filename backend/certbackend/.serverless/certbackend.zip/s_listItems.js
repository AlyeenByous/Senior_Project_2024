
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'dlg94490',
  applicationName: 'testhttp',
  appUid: 'qwVm73N73QcbzXzdPw',
  orgUid: '2701d1d4-013f-4ab9-afcd-f1dfbfd31d0e',
  deploymentUid: '6a3345eb-00b9-4810-9b9c-2c2d2d7add41',
  serviceName: 'certbackend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'certbackend-dev-listItems', timeout: 6 };

try {
  const userHandler = require('./listItems.js');
  module.exports.handler = serverlessSDK.handler(userHandler.listItems, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}