
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tempor',
  applicationName: 'tester',
  appUid: '9yCdZvP88hky4ClXg1',
  orgUid: '7acc9cab-a5d7-4586-9f43-219bd33bc886',
  deploymentUid: 'a34a80a5-bd5d-4039-8ddc-8c2e356f07c5',
  serviceName: 'certbackend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'certbackend-dev-hello', timeout: 6 };

try {
  const userHandler = require('./helloWorld.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}