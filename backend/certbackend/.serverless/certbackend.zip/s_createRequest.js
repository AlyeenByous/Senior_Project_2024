
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'dlg94490',
  applicationName: 'testhttp',
  appUid: 'qwVm73N73QcbzXzdPw',
  orgUid: '2701d1d4-013f-4ab9-afcd-f1dfbfd31d0e',
  deploymentUid: '7f3d8417-f85e-4b9f-a883-80439156772b',
  serviceName: 'certbackend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'certbackend-dev-createRequest', timeout: 6 };

try {
  const userHandler = require('./createRequest.js');
  module.exports.handler = serverlessSDK.handler(userHandler.createRequest, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}