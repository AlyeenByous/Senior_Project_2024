
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tempor',
  applicationName: 'tester',
  appUid: '9yCdZvP88hky4ClXg1',
  orgUid: '7acc9cab-a5d7-4586-9f43-219bd33bc886',
  deploymentUid: '4433893d-53f2-4e2c-92a5-877e3074640e',
  serviceName: 'certbackend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'certbackend-dev-createRequest', timeout: 6 };

try {
  const userHandler = require('./createRequest.js');
  module.exports.handler = serverlessSDK.handler(userHandler.createRequest, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}