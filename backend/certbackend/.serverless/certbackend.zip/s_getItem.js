
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tempor',
  applicationName: 'tester',
  appUid: '9yCdZvP88hky4ClXg1',
  orgUid: '7acc9cab-a5d7-4586-9f43-219bd33bc886',
  deploymentUid: 'd4f4b28d-5b3a-4e52-88cd-57d5e07758a4',
  serviceName: 'certbackend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'certbackend-dev-getItem', timeout: 6 };

try {
  const userHandler = require('./getItem.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getItem, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}